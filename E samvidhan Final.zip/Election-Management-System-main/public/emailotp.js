function sendOTP() {
   const email = document.getElementById('email');
   const otpverify = document.getElementsByClassName('otpverify')[0];

   const emailValue = email.value.trim();

   // ✅ Check if the email ends with @gmail.com
   if (!emailValue.endsWith('@gmail.com')) {
      alert("Only Gmail addresses are allowed to receive OTPs.");
      return;
   }

   let otp_val = Math.floor(1000 + Math.random() * 9000); // 4-digit OTP
   console.log("Generated OTP:", otp_val);

   let emailbody = `<h2>Your OTP is</h2><p>${otp_val}</p>`;

   Email.send({
      SecureToken : "bee42de2-71e7-4221-b865-9afe8ad36348",
      To : emailValue,
      From : "venkyrathod006@gmail.com",
      Subject : "Email OTP using JavaScript",
      Body : emailbody,
   }).then(
      message => {
         if (message === 'OK') {
            alert("OTP sent successfully to your Gmail!");
            // Show OTP verification field or handle next step
            otpverify.style.display = 'block';
         } else {
            alert("Failed to send OTP. Please try again.");
            console.error(message);
         }
      }
   );
}
